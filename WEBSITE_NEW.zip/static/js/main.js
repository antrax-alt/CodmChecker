// Global state
let currentFile = null;
let currentCheckId = null;
let isChecking = false;
let refreshInterval = null;
let settings = {
    threads: 3,
    autoRemove: false,
    saveCookies: true,
    useProxy: false,
    refreshInterval: 2,
    soundAlerts: false
};

// DOM Elements
const dropArea = document.getElementById('dropArea');
const fileInput = document.getElementById('fileInput');
const fileInfo = document.getElementById('fileInfo');
const fileName = document.getElementById('fileName');
const fileLines = document.getElementById('fileLines');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const resultsBtn = document.getElementById('resultsBtn');
const clearLog = document.getElementById('clearLog');
const logBody = document.getElementById('logBody');
const progressFill = document.getElementById('progressFill');
const progressText = document.getElementById('progressText');

// Stats Elements
const statValid = document.getElementById('statValid');
const statInvalid = document.getElementById('statInvalid');
const statClean = document.getElementById('statClean');
const statNotClean = document.getElementById('statNotClean');
const statHasCodm = document.getElementById('statHasCodm');
const statNoCodm = document.getElementById('statNoCodm');

// Tab Navigation
document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
        e.preventDefault();
        const tab = item.dataset.tab;
        
        // Update active nav
        document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
        item.classList.add('active');
        
        // Update active tab
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        document.getElementById(`${tab}-tab`).classList.add('active');
        
        // Load tab data if needed
        if (tab === 'history') {
            loadHistory();
        } else if (tab === 'results') {
            loadResults();
        }
    });
});

// File Upload Handling
dropArea.addEventListener('click', () => fileInput.click());

dropArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropArea.classList.add('dragover');
});

dropArea.addEventListener('dragleave', () => {
    dropArea.classList.remove('dragover');
});

dropArea.addEventListener('drop', (e) => {
    e.preventDefault();
    dropArea.classList.remove('dragover');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        handleFileUpload(files[0]);
    }
});

fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        handleFileUpload(e.target.files[0]);
    }
});

function handleFileUpload(file) {
    if (!file.name.endsWith('.txt')) {
        addLogEntry('Please upload a .txt file', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    
    addLogEntry(`Uploading ${file.name}...`, 'info');
    
    fetch('/api/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentFile = data;
            fileName.textContent = data.filename;
            fileLines.textContent = `${data.valid_lines} valid accounts`;
            fileInfo.style.display = 'flex';
            startBtn.disabled = false;
            addLogEntry(`File uploaded: ${data.filename} (${data.valid_lines} accounts)`, 'success');
            
            if (data.invalid_lines > 0) {
                addLogEntry(`Skipped ${data.invalid_lines} invalid lines`, 'warning');
            }
        } else {
            addLogEntry(`Upload failed: ${data.error}`, 'error');
        }
    })
    .catch(error => {
        addLogEntry(`Upload error: ${error.message}`, 'error');
    });
}

// Start Checking
startBtn.addEventListener('click', () => {
    if (!currentFile) return;
    
    // Get settings
    settings.threads = parseInt(document.getElementById('threads').value) || 3;
    settings.autoRemove = document.getElementById('autoRemove').checked;
    settings.saveCookies = document.getElementById('saveCookies').checked;
    
    addLogEntry(`Starting check with ${settings.threads} threads...`, 'system');
    
    fetch('/api/start', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            filename: currentFile.filename,
            threads: settings.threads,
            auto_remove: settings.autoRemove
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentCheckId = data.check_id;
            isChecking = true;
            startBtn.disabled = true;
            stopBtn.disabled = false;
            
            // Update IP if different
            if (data.client_ip && data.client_ip !== document.getElementById('clientIP').textContent) {
                document.getElementById('clientIP').textContent = data.client_ip;
            }
            
            addLogEntry(`Check started with ID: ${currentCheckId}`, 'success');
            addLogEntry(`Your IP: ${data.client_ip}`, 'info');
            
            // Start polling for updates
            startPolling();
        } else {
            addLogEntry(`Failed to start: ${data.error}`, 'error');
        }
    })
    .catch(error => {
        addLogEntry(`Start error: ${error.message}`, 'error');
    });
});

// Stop Checking
stopBtn.addEventListener('click', () => {
    if (!currentCheckId) return;
    
    fetch(`/api/stop/${currentCheckId}`, {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            addLogEntry('Check stopped by user', 'warning');
            stopBtn.disabled = true;
            startBtn.disabled = false;
            isChecking = false;
            stopPolling();
        }
    })
    .catch(error => {
        addLogEntry(`Stop error: ${error.message}`, 'error');
    });
});

// Results Button
resultsBtn.addEventListener('click', () => {
    fetch('/api/results')
    .then(response => response.json())
    .then(results => {
        showResultsModal(results);
    })
    .catch(error => {
        addLogEntry(`Failed to load results: ${error.message}`, 'error');
    });
});

// Clear Log
clearLog.addEventListener('click', () => {
    logBody.innerHTML = '';
    addLogEntry('Log cleared', 'system');
});

// Polling for updates
function startPolling() {
    if (refreshInterval) clearInterval(refreshInterval);
    
    refreshInterval = setInterval(() => {
        if (!currentCheckId || !isChecking) return;
        
        fetch(`/api/status/${currentCheckId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                if (data.error === 'Check not found') {
                    stopPolling();
                    isChecking = false;
                    startBtn.disabled = false;
                    stopBtn.disabled = true;
                    addLogEntry('Check completed', 'success');
                }
                return;
            }
            
            // Update stats
            updateStats(data);
            
            // Update progress
            const percent = (data.processed / data.total) * 100;
            progressFill.style.width = `${percent}%`;
            progressText.textContent = `${data.processed}/${data.total}`;
            
            // Check if completed
            if (data.status === 'completed' || data.status === 'stopped') {
                stopPolling();
                isChecking = false;
                startBtn.disabled = false;
                stopBtn.disabled = true;
                addLogEntry(`Check ${data.status}`, data.status === 'completed' ? 'success' : 'warning');
            }
        })
        .catch(() => {});
    }, settings.refreshInterval * 1000);
}

function stopPolling() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}

// Update stats display
function updateStats(data) {
    statValid.textContent = data.valid || 0;
    statInvalid.textContent = data.invalid || 0;
    statClean.textContent = data.clean || 0;
    statNotClean.textContent = data.not_clean || 0;
    statHasCodm.textContent = data.has_codm || 0;
    statNoCodm.textContent = data.no_codm || 0;
}

// Add log entry
function addLogEntry(message, type = 'info') {
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { 
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    
    let icon = '';
    switch(type) {
        case 'success':
            icon = '✓';
            break;
        case 'error':
            icon = '✗';
            break;
        case 'warning':
            icon = '⚠';
            break;
        case 'system':
            icon = '🔧';
            break;
        default:
            icon = 'ℹ';
    }
    
    entry.innerHTML = `
        <span class="log-time">[${timeStr}]</span>
        <span class="log-message">${icon} ${message}</span>
    `;
    
    logBody.appendChild(entry);
    logBody.scrollTop = logBody.scrollHeight;
    
    // Sound alert for valid hits
    if (type === 'success' && settings.soundAlerts) {
        playSound('success');
    }
}

// Play sound
function playSound(type) {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.type = 'sine';
    oscillator.frequency.value = type === 'success' ? 800 : 400;
    gainNode.gain.value = 0.1;
    
    oscillator.start();
    oscillator.stop(audioContext.currentTime + 0.1);
}

// Load history
function loadHistory() {
    const historyList = document.getElementById('historyList');
    historyList.innerHTML = '<div class="spinner"></div>';
    
    fetch('/api/results')
    .then(response => response.json())
    .then(results => {
        historyList.innerHTML = '';
        
        if (results.length === 0) {
            historyList.innerHTML = '<p style="text-align: center; color: var(--text-muted); padding: 40px;">No check history found</p>';
            return;
        }
        
        results.forEach(result => {
            const date = new Date(result.timestamp * 1000);
            const timeAgo = getTimeAgo(date);
            
            const item = document.createElement('div');
            item.className = 'history-item';
            item.innerHTML = `
                <div class="history-info">
                    <div class="history-icon">
                        <i class="fas fa-history"></i>
                    </div>
                    <div class="history-details">
                        <h4>Check #${result.check_id.substring(0, 8)}</h4>
                        <p>IP: ${result.client_ip} • ${timeAgo}</p>
                        <p>${result.files.length} result files</p>
                    </div>
                </div>
                <div class="history-status ${result.status}">
                    ${result.status}
                </div>
            `;
            
            item.addEventListener('click', () => {
                showCheckDetails(result);
            });
            
            historyList.appendChild(item);
        });
    })
    .catch(error => {
        historyList.innerHTML = `<p style="color: var(--danger);">Error loading history: ${error.message}</p>`;
    });
}

// Load results
function loadResults() {
    const resultsGrid = document.getElementById('resultsGrid');
    resultsGrid.innerHTML = '<div class="spinner"></div>';
    
    fetch('/api/results')
    .then(response => response.json())
    .then(results => {
        resultsGrid.innerHTML = '';
        
        if (results.length === 0) {
            resultsGrid.innerHTML = '<p style="text-align: center; color: var(--text-muted); padding: 40px;">No results found</p>';
            return;
        }
        
        results.forEach(result => {
            const date = new Date(result.timestamp * 1000);
            
            result.files.forEach(file => {
                const card = document.createElement('div');
                card.className = 'result-card';
                
                const fileSize = formatFileSize(file.size);
                
                card.innerHTML = `
                    <div class="result-header">
                        <i class="fas fa-file-alt"></i>
                        <h4>${file.name}</h4>
                    </div>
                    <div class="result-meta">
                        <span>${fileSize}</span>
                        <span>${date.toLocaleDateString()}</span>
                    </div>
                    <div style="margin-top: 12px; text-align: right;">
                        <a href="/api/download/${file.path}" class="btn-download" target="_blank">
                            <i class="fas fa-download"></i> Download
                        </a>
                    </div>
                `;
                
                resultsGrid.appendChild(card);
            });
        });
    })
    .catch(error => {
        resultsGrid.innerHTML = `<p style="color: var(--danger);">Error loading results: ${error.message}</p>`;
    });
}

// Show results modal
function showResultsModal(results) {
    const modal = document.getElementById('resultsModal');
    const modalBody = document.getElementById('modalBody');
    
    modalBody.innerHTML = '';
    
    if (results.length === 0) {
        modalBody.innerHTML = '<p style="text-align: center; color: var(--text-muted);">No results found</p>';
    } else {
        results.forEach(result => {
            result.files.forEach(file => {
                const item = document.createElement('div');
                item.className = 'modal-file-item';
                
                const fileSize = formatFileSize(file.size);
                
                item.innerHTML = `
                    <div class="modal-file-info">
                        <i class="fas fa-file-alt"></i>
                        <div>
                            <div class="modal-file-name">${file.name}</div>
                            <div class="modal-file-size">${fileSize}</div>
                        </div>
                    </div>
                    <a href="/api/download/${file.path}" class="modal-download" target="_blank">
                        <i class="fas fa-download"></i>
                    </a>
                `;
                
                modalBody.appendChild(item);
            });
        });
    }
    
    modal.classList.add('active');
}

// Close modal
document.querySelector('.modal-close').addEventListener('click', () => {
    document.getElementById('resultsModal').classList.remove('active');
});

// Click outside modal to close
window.addEventListener('click', (e) => {
    const modal = document.getElementById('resultsModal');
    if (e.target === modal) {
        modal.classList.remove('active');
    }
});

// Format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Get time ago string
function getTimeAgo(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + ' years ago';
    
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + ' months ago';
    
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + ' days ago';
    
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + ' hours ago';
    
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + ' minutes ago';
    
    return 'just now';
}

// Show check details
function showCheckDetails(result) {
    const modal = document.getElementById('resultsModal');
    const modalBody = document.getElementById('modalBody');
    
    modalBody.innerHTML = '';
    
    result.files.forEach(file => {
        const item = document.createElement('div');
        item.className = 'modal-file-item';
        
        const fileSize = formatFileSize(file.size);
        
        item.innerHTML = `
            <div class="modal-file-info">
                <i class="fas fa-file-alt"></i>
                <div>
                    <div class="modal-file-name">${file.name}</div>
                    <div class="modal-file-size">${fileSize}</div>
                </div>
            </div>
            <a href="/api/download/${file.path}" class="modal-download" target="_blank">
                <i class="fas fa-download"></i>
            </a>
        `;
        
        modalBody.appendChild(item);
    });
    
    modal.classList.add('active');
}

// Settings
document.getElementById('maxThreads').addEventListener('change', (e) => {
    settings.threads = parseInt(e.target.value);
    document.getElementById('threads').value = settings.threads;
});

document.getElementById('refreshInterval').addEventListener('change', (e) => {
    settings.refreshInterval = parseInt(e.target.value);
    if (isChecking) {
        stopPolling();
        startPolling();
    }
});

document.getElementById('soundAlerts').addEventListener('change', (e) => {
    settings.soundAlerts = e.target.checked;
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl+Enter to start
    if (e.ctrlKey && e.key === 'Enter' && !startBtn.disabled) {
        startBtn.click();
    }
    
    // Ctrl+Shift+Enter to stop
    if (e.ctrlKey && e.shiftKey && e.key === 'Enter' && !stopBtn.disabled) {
        stopBtn.click();
    }
    
    // Ctrl+L to clear log
    if (e.ctrlKey && e.key === 'l') {
        e.preventDefault();
        clearLog.click();
    }
    
    // Ctrl+D to open results
    if (e.ctrlKey && e.key === 'd') {
        e.preventDefault();
        resultsBtn.click();
    }
});

// Get initial IP
fetch('/api/ip')
.then(response => response.json())
.then(data => {
    if (data.ip) {
        document.getElementById('clientIP').textContent = data.ip;
    }
});

// Initial log entry
addLogEntry('Garena Account Checker initialized', 'system');
addLogEntry('Upload a combo file to begin', 'info');

// Clean up on page unload
window.addEventListener('beforeunload', () => {
    if (isChecking && currentCheckId) {
        fetch(`/api/stop/${currentCheckId}`, { method: 'POST', keepalive: true });
    }
});